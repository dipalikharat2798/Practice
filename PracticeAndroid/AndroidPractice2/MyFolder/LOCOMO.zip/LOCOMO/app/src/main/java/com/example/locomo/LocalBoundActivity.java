package com.example.locomo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.locomo.Service.BoundService;

public class LocalBoundActivity extends AppCompatActivity implements View.OnClickListener{
    private static String TAG = "LocalBoundActivity";
    BoundService myService;
    boolean isBound = false;
    String timer;
    boolean timerStarted = false;
    Button btn1,btn2,btn3;

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            timer = intent.getStringExtra("Timer");
            Log.d(TAG, "onReceive: " + timer);
            TextView myTextView =
                    (TextView) findViewById(R.id.showtime_tv);
            myTextView.setText(timer);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_bound);
        btn1=findViewById(R.id.showtime_btn);
        btn2=findViewById(R.id.stoptimer_btn);
        btn3=findViewById(R.id.reset_btn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showtime();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopTimer();
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
            }
        });
    }

    private ServiceConnection myConnection = new ServiceConnection()
    {
        @Override
        public void onServiceConnected(ComponentName className,
                                       IBinder service) {
            BoundService.MyLocalBinder binder = (BoundService.MyLocalBinder) service;
            myService = binder.getService();
            isBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };

    public void showtime() {
        if (timerStarted==false) {
            timerStarted=true;
            startService();
        }
    }

    public void stopTimer() {
        if (timerStarted==true) {
            timerStarted=false;
            myService.stopTimer();
        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(mReceiver, new IntentFilter(BoundService.SERVICE_MESSAGE));
    }

    @Override
    public void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(getApplicationContext()).unregisterReceiver(mReceiver);        //<-- Unregister to avoid memoryleak
    }

    public void resetTimer() {
        myService.resetTimer();
    }

    private void startService(){
        Intent serviceIntent = new Intent(LocalBoundActivity.this,BoundService.class);
        startService(serviceIntent);
        bindService();
    }
    private void bindService(){
        Intent serviceIntent = new Intent(LocalBoundActivity.this,BoundService.class);
       bindService(serviceIntent,myConnection,Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onClick(View v) {
        
    }
}