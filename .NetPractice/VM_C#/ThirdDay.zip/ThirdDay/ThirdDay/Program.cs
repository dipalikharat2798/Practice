﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThirdDay
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee obj = new Employee();
            Employee obj1 = new Employee(1,"a","b","c");
            //obj.DisplayDetails();
            Console.Read();
        }
    }
}
